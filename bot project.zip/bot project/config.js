/**
 * Central configuration file for Aozora Staff Application Bot
 */
module.exports = {
  // Guilds
  MAIN_GUILD_ID: '1231482071499800638',
  STAFF_GUILD_ID: '1287247262023548998',

  // Channels
  APPLICATION_CHANNEL_ID: '1323261673225846784',
  REVIEW_CHANNEL_ID: '1287247262463819806',

  // Roles
  STAFF_ROLE_ID: '1231482071675830326',
  TRIAL_ROLE_ID: '1284161574868877407',

  // Bot Status
  STREAMING_STATUS_TEXT: "Looking for applicants to Aozora",
  STREAMING_URL: "https://twitch.tv/discord", // Required for STREAMING activity type

  // 11 Application Questions (based on screenshot fields)
  QUESTIONS: [
    {
      id: 1,
      text: "**Question 1:** Full name *",
      type: "text",
      required: true
    },
    {
      id: 2,
      text: "**Question 2:** Your discord username *",
      type: "text",
      required: true
    },
    {
      id: 3,
      text: "**Question 3:** Your Discord user ID\n*(Skip this if you don't know how to find your discord user ID)*",
      type: "text",
      required: false
    },
    {
      id: 4,
      text: "**Question 4:** Date of birth *\n*(Please input date as M/d/yyyy, e.g. 10/25/2005)*",
      type: "text",
      required: true,
      validate: (input) => {
        const regex = /^\d{1,2}\/\d{1,2}\/\d{4}$/;
        if (!regex.test(input)) {
          return "❌ Invalid date format. Please enter in **M/d/yyyy** format (e.g. 10/25/2005).";
        }
        const parts = input.split('/');
        const month = parseInt(parts[0], 10);
        const day = parseInt(parts[1], 10);
        const year = parseInt(parts[2], 10);
        
        if (month < 1 || month > 12) return "❌ Invalid month. Please check your input.";
        if (day < 1 || day > 31) return "❌ Invalid day. Please check your input.";
        const currentYear = new Date().getFullYear();
        if (year < 1920 || year > currentYear) return "❌ Invalid year. Please check your input.";
        
        return true;
      }
    },
    {
      id: 5,
      text: "**Question 5:** Do you have any past experience working in any server before? (Proof link required as well) *\n*(Want to upload the proof via link? try https://imgbb.com/ and send the proof link)*",
      type: "text",
      required: true
    },
    {
      id: 6,
      text: "**Question 6:** How long have you worked in other server? if did",
      type: "text",
      required: false
    },
    {
      id: 7,
      text: "**Question 7:** Are you able to start work immediately? *",
      type: "button",
      required: true,
      options: [
        { label: "Yes", value: "Yes", style: "Success" }, // SUCCESS (Green)
        { label: "No", value: "No", style: "Danger" }     // DANGER (Red)
      ]
    },
    {
      id: 8,
      text: "**Question 8:** What is your time zone? *",
      type: "text",
      required: true
    },
    {
      id: 9,
      text: "**Question 9:** How much active you could be in Aozora in your time on discord? *",
      type: "select",
      required: true,
      placeholder: "Select your active level (1 = least active, 10 = most active)",
      options: [
        { label: "1 (Very low activity)", value: "1" },
        { label: "2", value: "2" },
        { label: "3", value: "3" },
        { label: "4", value: "4" },
        { label: "5 (Moderate activity)", value: "5" },
        { label: "6", value: "6" },
        { label: "7", value: "7" },
        { label: "8", value: "8" },
        { label: "9", value: "9" },
        { label: "10 (Highly active)", value: "10" }
      ]
    },
    {
      id: 10,
      text: "**Question 10:** Purpose of applying for the Staff in Aozora? *",
      type: "text",
      required: true
    },
    {
      id: 11,
      text: "**Question 11:** How will you handle a raid in server or an emergency situation? Give us your statement *",
      type: "text",
      required: true
    }
  ]
};
