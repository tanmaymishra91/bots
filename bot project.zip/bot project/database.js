const fs = require('fs');
const path = require('path');

const DB_FILE = path.join(__dirname, 'database.json');

// In-memory data store structure
let db = {
  active_applications: {}, // userId -> { currentQuestionIndex, answers: [] }
  submitted_applications: {} // applicationId -> { userId, username, answers: [], status: 'pending' | 'approved' | 'denied', staffId: null, timestamp: null }
};

/**
 * Loads data from database.json or initializes a new one.
 */
function init() {
  try {
    if (fs.existsSync(DB_FILE)) {
      const data = fs.readFileSync(DB_FILE, 'utf8');
      db = JSON.parse(data);
      // Ensure structures are present
      if (!db.active_applications) db.active_applications = {};
      if (!db.submitted_applications) db.submitted_applications = {};
    } else {
      save();
    }
  } catch (err) {
    console.error("Failed to initialize database, using empty store:", err);
  }
}

/**
 * Saves current in-memory store to database.json atomically.
 */
function save() {
  try {
    // Write to a temporary file first, then rename it, to prevent data corruption
    const tempFile = DB_FILE + '.tmp';
    fs.writeFileSync(tempFile, JSON.stringify(db, null, 2), 'utf8');
    fs.renameSync(tempFile, DB_FILE);
  } catch (err) {
    console.error("Failed to save database to disk:", err);
  }
}

module.exports = {
  init,

  /**
   * Get active application state for a user
   * @param {string} userId 
   */
  getActiveApplication(userId) {
    return db.active_applications[userId] || null;
  },

  /**
   * Save or update active application state
   * @param {string} userId 
   * @param {object} appState 
   */
  saveActiveApplication(userId, appState) {
    db.active_applications[userId] = appState;
    save();
  },

  /**
   * Delete active application state
   * @param {string} userId 
   */
  deleteActiveApplication(userId) {
    if (db.active_applications[userId]) {
      delete db.active_applications[userId];
      save();
    }
  },

  /**
   * Save a completed application before review
   * @param {string} applicationId - Unique ID (e.g. staff review message ID)
   * @param {string} userId 
   * @param {string} username 
   * @param {Array} answers 
   * @param {string} duration
   */
  createSubmittedApplication(applicationId, userId, username, answers, duration) {
    db.submitted_applications[applicationId] = {
      userId,
      username,
      answers,
      duration: duration || "Unknown",
      status: 'pending',
      staffId: null,
      timestamp: new Date().toISOString()
    };
    save();
  },

  /**
   * Get submitted application by its ID (message ID)
   * @param {string} applicationId 
   */
  getSubmittedApplication(applicationId) {
    return db.submitted_applications[applicationId] || null;
  },

  /**
   * Update the status of a submitted application (approved / denied)
   * @param {string} applicationId 
   * @param {'approved'|'denied'} status 
   * @param {string} staffId 
   */
  updateApplicationStatus(applicationId, status, staffId) {
    if (db.submitted_applications[applicationId]) {
      db.submitted_applications[applicationId].status = status;
      db.submitted_applications[applicationId].staffId = staffId;
      save();
      return true;
    }
    return false;
  },

  /**
   * Delete submitted application state entirely
   * @param {string} applicationId 
   */
  deleteSubmittedApplication(applicationId) {
    if (db.submitted_applications[applicationId]) {
      delete db.submitted_applications[applicationId];
      save();
    }
  }
};
