# Aozora Staff Application Discord Bot

An interactive Discord bot written in Node.js utilizing **discord.js v14** to streamline the staff application process for the **Aozora** server. 

## Features

- **Interactive Public Prompt:** Auto-posts (and updates on reboot) a clean embed with an "Apply for Staff" button in your server's application channel.
- **Direct Message (DM) Questionnaire:** Guides applicants through the 11 questions one-by-one inside their DMs.
- **Interactive Forms:** Includes buttons for Yes/No questions (Question 7), string select dropdown menus for scale questions (Question 9), and a "Skip Question" button for optional fields.
- **Application Review Panel:** Summarizes responses for the applicant and allows them to **Confirm & Submit** or **Cancel** before delivery.
- **Completion Time Tracking:** Calculates and logs the exact duration the applicant took to complete the questionnaire, displaying it in the review logs.
- **Staff Control Hub:** Posts applications in the Staff Server's review channel with interactive **Approve** and **Deny** buttons.
- **Automatic Staff Setup:** 
  - On **Approve**: DMs the user a congratulatory message and automatically grants them the **Staff** and **Trial** roles in the main guild.
  - On **Deny**: DMs the user a polite regret message.
- **Persistent State:** Saves active questionnaire sessions and review records to a local file database (`database.json`) so nothing is lost if the bot crashes or restarts.
- **Streaming Presence Status:** Custom streaming activity showing: `Streaming: Looking for applicants to Aozora`.

---

## Prerequisites

1. **Node.js** (v16.9.0 or higher) and **npm** must be installed on the hosting machine.
   - If not installed, download and install Node.js from [nodejs.org](https://nodejs.org/).
   - Ensure `node` and `npm` are added to your system's Environment Variables (PATH).

---

## Setup Instructions

### 1. Configure the Environment variables
Create a `.env` file in the root of the project folder (a `.env` template has been pre-created for you). Open it and replace the placeholder value with your actual bot token:
```env
DISCORD_TOKEN=your_actual_discord_bot_token_here
```

### 2. Verify config.js
All IDs are configured in [config.js](file:///C:/Work/bot%20project/config.js). They are set up as follows based on your specifications:
- **Main Server ID:** `1231482071499800638`
- **Application Prompt Channel ID:** `1323261673225846784`
- **Staff Server ID:** `1287247262023548998`
- **Staff Review Channel ID:** `1287247262463819806`
- **Staff Role ID:** `1231482071675830326`
- **Trial Role ID:** `1284161574868877407`

### 3. Install Dependencies
Open your command terminal (Powershell/Command Prompt), navigate to the directory `C:\Work\bot project`, and run:
```bash
npm install
```

### 4. Run the Bot
To start the bot in production mode:
```bash
npm start
```

---

## Required Discord Portal Configurations

To ensure the bot functions correctly, you must adjust these settings in the [Discord Developer Portal](https://discord.com/developers/applications):

1. **Enable Gateway Intents:**
   - Under your Application page, navigate to **Bot** -> **Privileged Gateway Intents**.
   - Enable **Server Members Intent** (required to search members and assign roles).
   - Enable **Message Content Intent** (required to read DM replies).
   - Save changes.

2. **Role Hierarchy Permissions:**
   - The bot's custom role (generated automatically when it joins) must be positioned **above** both the **Staff** (`1231482071675830326`) and **Trial** (`1284161574868877407`) roles in the server's Role list.
   - If the bot's role is below either of these, Discord will deny the bot permission to assign them, resulting in role hierarchy errors.
   - The bot must also have the **Manage Roles** permission enabled.
