require('dotenv').config();
const { 
  Client, 
  GatewayIntentBits, 
  Partials, 
  EmbedBuilder, 
  ActionRowBuilder, 
  ButtonBuilder, 
  ButtonStyle, 
  StringSelectMenuBuilder, 
  ActivityType 
} = require('discord.js');

const config = require('./config');
const database = require('./database');

// Initialize database
database.init();

// Create Discord client with correct intents and partials for DMs
const client = new Client({
  intents: [
    GatewayIntentBits.Guilds,
    GatewayIntentBits.GuildMessages,
    GatewayIntentBits.DirectMessages,
    GatewayIntentBits.MessageContent,
    GatewayIntentBits.GuildMembers
  ],
  partials: [
    Partials.Channel, // Crucial for receiving DM events in older/new DM channels
    Partials.Message,
    Partials.User
  ]
});

// Bot ready event
client.once('ready', async () => {
  console.log(`🤖 Logged in as ${client.user.tag}!`);

  // Set streaming status presence
  client.user.setPresence({
    activities: [{
      name: config.STREAMING_STATUS_TEXT,
      type: ActivityType.Streaming,
      url: config.STREAMING_URL
    }],
    status: 'online'
  });
  console.log(`📡 Status set to Streaming: "${config.STREAMING_STATUS_TEXT}"`);

  // Setup the public application prompt message
  await setupApplicationPrompt();
});

/**
 * Checks the public application channel and sends/updates the application prompt message.
 */
async function setupApplicationPrompt() {
  try {
    const channel = await client.channels.fetch(config.APPLICATION_CHANNEL_ID);
    if (!channel) {
      console.error(`❌ Could not find application channel with ID ${config.APPLICATION_CHANNEL_ID}`);
      return;
    }

    // Embed message layout for the apply prompt
    const embed = new EmbedBuilder()
      .setTitle("🌸 Aozora Staff Applications")
      .setDescription(
        "Welcome to the official **Aozora** Staff Applications recruitment desk!\n\n" +
        "We are looking for dedicated, active, and helpful members to join our moderation and support team. " +
        "If you believe you have what it takes to help grow and protect our community, click the button below to start your application.\n\n" +
        "📋 **How it works:**\n" +
        "1. Click the **Apply for Staff** button below.\n" +
        "2. The bot will send you a Direct Message (DM) to begin the application.\n" +
        "3. Answer the 11 questions one by one.\n" +
        "4. Confirm and submit. Your application will be sent to the staff team for review.\n\n" +
        "⚠️ **Note:** Please make sure your DMs are open to server members in your privacy settings before clicking the button!"
      )
      .setColor('#5865F2') // Discord Blurple
      .setFooter({ text: "Aozora Staff Recruitment", iconURL: client.user.displayAvatarURL() })
      .setTimestamp();

    const row = new ActionRowBuilder().addComponents(
      new ButtonBuilder()
        .setCustomId('aozora_apply_start')
        .setLabel('Apply for Staff')
        .setStyle(ButtonStyle.Primary)
        .setEmoji('📝')
    );

    // Fetch the specific configured message by ID to reuse it
    let existingMessage = null;
    if (config.APPLICATION_MESSAGE_ID) {
      existingMessage = await channel.messages.fetch(config.APPLICATION_MESSAGE_ID).catch(() => null);
    }

    // Fallback: search history if the specified message was not found or not configured
    if (!existingMessage) {
      console.log(`⚠️ Configured message ID ${config.APPLICATION_MESSAGE_ID} not found. Searching history...`);
      const messages = await channel.messages.fetch({ limit: 50 });
      existingMessage = messages.find(msg => msg.author.id === client.user.id && msg.embeds.length > 0 && msg.embeds[0].title === "🌸 Aozora Staff Applications");
    }

    if (existingMessage) {
      await existingMessage.edit({ embeds: [embed], components: [row] });
      console.log(`✏️ Application prompt message updated (ID: ${existingMessage.id}).`);
    } else {
      const sentMsg = await channel.send({ embeds: [embed], components: [row] });
      console.log(`✨ New application prompt message sent (ID: ${sentMsg.id}).`);
    }
  } catch (err) {
    console.error("❌ Error setting up application prompt channel message:", err);
  }
}

// Interaction listener
client.on('interactionCreate', async (interaction) => {
  try {
    // 1. Handle Public "Apply for Staff" button click
    if (interaction.isButton() && interaction.customId === 'aozora_apply_start') {
      await handleApplyStart(interaction);
      return;
    }

    // 2. Handle buttons and menus in DMs
    if (!interaction.guildId) {
      await handleDMInteraction(interaction);
      return;
    }

    // 3. Handle Staff Review buttons (Approve / Deny)
    if (interaction.isButton() && (interaction.customId.startsWith('aozora_staff_approve:') || interaction.customId.startsWith('aozora_staff_deny:'))) {
      await handleStaffReviewAction(interaction);
      return;
    }
  } catch (err) {
    console.error("Error handling interaction:", err);
  }
});

// DM Message Listener (for text answers)
client.on('messageCreate', async (message) => {
  if (message.author.bot) return;
  if (message.guildId) return; // Only process DMs

  try {
    const userId = message.author.id;
    const appState = database.getActiveApplication(userId);

    if (!appState) {
      // User is typing in DM but doesn't have an active application
      return;
    }

    const questionIndex = appState.currentQuestionIndex;
    const question = config.QUESTIONS[questionIndex];

    if (!question) {
      return;
    }

    // If the question is an interactive button or select menu type, prompt them to click instead of typing
    if (question.type === 'button' || question.type === 'select') {
      await message.reply({
        content: `⚠️ This question requires you to select an option using the buttons or dropdown menu provided above. Please use them to submit your answer!`
      });
      return;
    }

    // Validate the text answer if a validator exists
    if (question.validate) {
      const validationResult = question.validate(message.content);
      if (validationResult !== true) {
        await message.reply({ content: validationResult });
        return;
      }
    }

    // Save answer
    appState.answers.push({
      questionId: question.id,
      questionText: question.text.split('\n')[0].replace(/\*\*|#/g, ''), // clean styling
      answer: message.content.trim()
    });

    // Advance state
    appState.currentQuestionIndex++;
    database.saveActiveApplication(userId, appState);

    // Ask next question
    await askQuestion(message.author, appState.currentQuestionIndex);
  } catch (err) {
    console.error("Error processing DM message:", err);
  }
});

/**
 * Handles the click on the initial "Apply for Staff" button in the public server.
 */
async function handleApplyStart(interaction) {
  const userId = interaction.user.id;
  const user = interaction.user;

  await interaction.deferReply({ ephemeral: true });

  // Verify the user is in the main server
  try {
    const mainGuild = await client.guilds.fetch(config.MAIN_GUILD_ID);
    const member = await mainGuild.members.fetch(userId);
    if (!member) {
      await interaction.followUp({ content: "❌ You must be a member of the Aozora Discord server to apply.", ephemeral: true });
      return;
    }
  } catch (err) {
    await interaction.followUp({ content: "❌ An error occurred verifying your membership. Please try again later.", ephemeral: true });
    return;
  }

  // Check if they already have an active application
  const existingApp = database.getActiveApplication(userId);
  if (existingApp) {
    try {
      await user.send({
        content: "👋 It looks like you have an active application in progress already! Let's resume from where you left off."
      });
      await askQuestion(user, existingApp.currentQuestionIndex);
      await interaction.followUp({ content: "📩 You already have an active application in progress. I have sent you a DM to continue!", ephemeral: true });
      return;
    } catch (err) {
      await interaction.followUp({ content: "❌ I tried to DM you, but failed. Please enable DMs from server members in your privacy settings and try again.", ephemeral: true });
      return;
    }
  }

  // Try sending DM to open the session
  try {
    const welcomeEmbed = new EmbedBuilder()
      .setTitle("📋 Aozora Staff Application")
      .setDescription(
        "Thank you for your interest in joining the **Aozora** staff team! " +
        "I will ask you 11 questions. Please answer them carefully.\n\n" +
        "💡 *Tip: If you make a mistake, you can click Cancel at the end and start over.*"
      )
      .setColor('#5865F2')
      .setTimestamp();

    await user.send({ embeds: [welcomeEmbed] });

    // Initialize state
    database.saveActiveApplication(userId, {
      currentQuestionIndex: 0,
      answers: [],
      startTime: Date.now() // Record starting time
    });

    // Ask first question
    await askQuestion(user, 0);

    await interaction.followUp({ content: "📩 I've sent you a DM to start the application process! Please check your DMs.", ephemeral: true });
  } catch (err) {
    console.error("Failed to send welcome DM:", err);
    await interaction.followUp({ content: "❌ I couldn't send you a DM. Please check if you have allowed Direct Messages from server members in your Privacy settings.", ephemeral: true });
  }
}

/**
 * Sends the question at the specified index to the user.
 */
async function askQuestion(user, index) {
  const appState = database.getActiveApplication(user.id);
  if (!appState) return;

  // Check if we finished all questions
  if (index >= config.QUESTIONS.length) {
    await sendSummaryAndConfirmation(user, appState.answers);
    return;
  }

  const question = config.QUESTIONS[index];
  const payload = { content: question.text };

  // Add interactive components if appropriate
  if (question.type === 'button') {
    const row = new ActionRowBuilder();
    question.options.forEach(opt => {
      const style = opt.style === 'Success' ? ButtonStyle.Success : ButtonStyle.Danger;
      row.addComponents(
        new ButtonBuilder()
          .setCustomId(`aozora_q_${question.id}_val:${opt.value}`)
          .setLabel(opt.label)
          .setStyle(style)
      );
    });
    payload.components = [row];
  } else if (question.type === 'select') {
    const select = new StringSelectMenuBuilder()
      .setCustomId(`aozora_q_${question.id}_select`)
      .setPlaceholder(question.placeholder || "Select an option")
      .addOptions(question.options.map(opt => ({
        label: opt.label,
        value: opt.value
      })));
    payload.components = [new ActionRowBuilder().addComponents(select)];
  } else if (question.required === false) {
    // For optional text questions (Q3 & Q6), provide a "Skip" button
    const skipRow = new ActionRowBuilder().addComponents(
      new ButtonBuilder()
        .setCustomId(`aozora_q_${question.id}_skip`)
        .setLabel("Skip Question")
        .setStyle(ButtonStyle.Secondary)
    );
    payload.components = [skipRow];
  }

  await user.send(payload);
}

/**
 * Handles button or select menu actions taken in the user's DM.
 */
async function handleDMInteraction(interaction) {
  const userId = interaction.user.id;
  const appState = database.getActiveApplication(userId);

  if (!appState) {
    await interaction.reply({ content: "❌ No active application session found. You can start a new one in the server.", ephemeral: true });
    return;
  }

  const customId = interaction.customId;

  // 1. Handle user canceling application
  if (customId === 'aozora_app_cancel') {
    database.deleteActiveApplication(userId);
    await interaction.update({
      content: "❌ **Application cancelled.** You can start a new application at any time by clicking the button in the server.",
      embeds: [],
      components: []
    });
    return;
  }

  // 2. Handle user submitting application
  if (customId === 'aozora_app_submit') {
    await handleApplicationSubmit(interaction, appState);
    return;
  }

  // 3. Handle question interactive answers (buttons, selects, skips)
  const questionIndex = appState.currentQuestionIndex;
  const question = config.QUESTIONS[questionIndex];

  if (!question) {
    await interaction.reply({ content: "❌ Application state mismatch. Please try again.", ephemeral: true });
    return;
  }

  let answerText = "";

  if (customId.startsWith(`aozora_q_${question.id}_val:`)) {
    // Button option clicked
    answerText = customId.split(':')[1];
  } else if (customId === `aozora_q_${question.id}_select` && interaction.isStringSelectMenu()) {
    // Select option chosen
    answerText = interaction.values[0];
  } else if (customId === `aozora_q_${question.id}_skip`) {
    // Optional question skipped
    answerText = "Skipped (Not Provided)";
  } else {
    // Out-of-order interaction or mismatched button
    await interaction.reply({ content: "⚠️ Please answer the current question first.", ephemeral: true });
    return;
  }

  // Save the answer
  appState.answers.push({
    questionId: question.id,
    questionText: question.text.split('\n')[0].replace(/\*\*|#/g, ''),
    answer: answerText
  });

  // Disable components in the answered question to prevent double clicking
  await interaction.update({
    content: `${question.text}\n*Answered: **${answerText}***`,
    components: []
  });

  // Advance index and save state
  appState.currentQuestionIndex++;
  database.saveActiveApplication(userId, appState);

  // Ask next question
  await askQuestion(interaction.user, appState.currentQuestionIndex);
}

/**
 * Compiles answers and presents a final confirmation panel to the user in DMs.
 */
async function sendSummaryAndConfirmation(user, answers) {
  const embed = new EmbedBuilder()
    .setTitle("📝 Application Review")
    .setDescription("Please review your answers below. If everything looks correct, click **Confirm & Submit**. Otherwise, you can **Cancel** and start again.")
    .setColor('#E67E22')
    .setTimestamp();

  answers.forEach(item => {
    // Safely format field content
    const questionLabel = item.questionText.trim();
    const answerLabel = item.answer.substring(0, 1000) || "*(Empty)*";
    embed.addFields({ name: questionLabel, value: answerLabel, inline: false });
  });

  const row = new ActionRowBuilder().addComponents(
    new ButtonBuilder()
      .setCustomId('aozora_app_submit')
      .setLabel('Confirm & Submit')
      .setStyle(ButtonStyle.Success)
      .setEmoji('✅'),
    new ButtonBuilder()
      .setCustomId('aozora_app_cancel')
      .setLabel('Cancel Application')
      .setStyle(ButtonStyle.Danger)
      .setEmoji('❌')
  );

  await user.send({ embeds: [embed], components: [row] });
}

/**
 * Submits the application, posts it to the staff review channel, and cleans up the DM session.
 */
async function handleApplicationSubmit(interaction, appState) {
  const userId = interaction.user.id;
  const user = interaction.user;

  try {
    // 1. Get staff review channel
    const reviewChannel = await client.channels.fetch(config.REVIEW_CHANNEL_ID).catch(() => null);
    if (!reviewChannel) {
      await interaction.reply({ content: "❌ Unable to contact the staff review channel. Please contact a staff member directly.", ephemeral: true });
      console.error(`❌ Review channel ${config.REVIEW_CHANNEL_ID} not found.`);
      return;
    }

    // Calculate duration
    const startTime = appState.startTime || Date.now();
    const durationText = formatDuration(Date.now() - startTime);

    // 2. Build review embed
    const reviewEmbed = new EmbedBuilder()
      .setTitle("📩 New Staff Application")
      .setDescription(`**Applicant:** ${user} | \`${user.tag}\` (ID: \`${userId}\`)\n**Status:** ⏳ Pending Review\n**Time Taken to Apply:** ${durationText}`)
      .setColor('#3498db')
      .setThumbnail(user.displayAvatarURL({ dynamic: true }))
      .setTimestamp();

    appState.answers.forEach(item => {
      const q = item.questionText.trim();
      const a = item.answer.trim().substring(0, 1020) || "*(No response)*";
      reviewEmbed.addFields({ name: q, value: a, inline: false });
    });

    const staffRow = new ActionRowBuilder().addComponents(
      new ButtonBuilder()
        .setCustomId(`aozora_staff_approve:${userId}`)
        .setLabel('Approve')
        .setStyle(ButtonStyle.Success)
        .setEmoji('✔️'),
      new ButtonBuilder()
        .setCustomId(`aozora_staff_deny:${userId}`)
        .setLabel('Deny')
        .setStyle(ButtonStyle.Danger)
        .setEmoji('✖️')
    );

    // 3. Send application to staff channel
    const staffMessage = await reviewChannel.send({
      content: `🔔 **New application from ${user}**`,
      embeds: [reviewEmbed],
      components: [staffRow]
    });

    // 4. Save to submitted application database keyed by staff message ID
    database.createSubmittedApplication(
      staffMessage.id,
      userId,
      user.username,
      appState.answers,
      durationText
    );

    // 5. Clean up active DM state
    database.deleteActiveApplication(userId);

    // 6. Respond to user in DM
    await interaction.update({
      content: "🎉 **Thank you for applying!** Your staff application has been successfully submitted to the **Aozora** Staff team. We will review it shortly.",
      embeds: [],
      components: []
    });
  } catch (err) {
    console.error("Error during application submission:", err);
    await interaction.reply({ content: "❌ Something went wrong while submitting. Please try again.", ephemeral: true });
  }
}

/**
 * Handles action taken by a staff member on a submitted application (Approve / Deny).
 */
async function handleStaffReviewAction(interaction) {
  const staffUser = interaction.user;
  const customId = interaction.customId;
  const isApprove = customId.startsWith('aozora_staff_approve:');
  const userId = customId.split(':')[1];
  const messageId = interaction.message.id;

  await interaction.deferReply({ ephemeral: true });

  // Retrieve application data
  const appData = database.getSubmittedApplication(messageId);
  if (!appData) {
    await interaction.followUp({ content: "❌ Application details not found in database.", ephemeral: true });
    return;
  }

  if (appData.status !== 'pending') {
    await interaction.followUp({ content: `❌ This application has already been processed as **${appData.status.toUpperCase()}**.`, ephemeral: true });
    // Safe fallback to disable buttons if they are somehow still active
    await disableMessageButtons(interaction.message);
    return;
  }

  const mainGuild = await client.guilds.fetch(config.MAIN_GUILD_ID).catch(() => null);
  if (!mainGuild) {
    await interaction.followUp({ content: "❌ Main guild is offline or unreachable by the bot.", ephemeral: true });
    return;
  }

  // Update status locally
  const newStatus = isApprove ? 'approved' : 'denied';
  database.updateApplicationStatus(messageId, newStatus, staffUser.id);

  // Attempt to fetch member to perform actions
  const member = await mainGuild.members.fetch(userId).catch(() => null);

  let actionDetails = "";

  if (isApprove) {
    // 1. Assign roles
    if (member) {
      try {
        const staffRole = await mainGuild.roles.fetch(config.STAFF_ROLE_ID);
        const trialRole = await mainGuild.roles.fetch(config.TRIAL_ROLE_ID);

        if (staffRole && trialRole) {
          await member.roles.add([staffRole, trialRole]);
          actionDetails = "\n✅ Roles **Staff** and **Trial** have been successfully assigned.";
        } else {
          actionDetails = "\n⚠️ Roles could not be assigned: Check if Role IDs exist on the server.";
        }
      } catch (err) {
        console.error("Error assigning roles:", err);
        actionDetails = `\n⚠️ Failed to assign roles automatically (Role hierarchy issue or missing bot permission).`;
      }
    } else {
      actionDetails = "\n⚠️ Applicant is no longer in the server; roles could not be assigned.";
    }

    // 2. DM user congratulations
    try {
      const applicantUser = member ? member.user : await client.users.fetch(userId);
      await applicantUser.send({
        content: `🎉 **Congratulations!** Your staff application for **Aozora** has been **approved**! Welcome to the team.\n\nYou have been granted the Staff and Trial roles. Please head over to the staff channels for further instructions.`
      });
    } catch (err) {
      actionDetails += "\n⚠️ Could not DM the user (their DMs might be closed).";
    }

  } else {
    // Rejection handling
    // DM user regret message
    try {
      const applicantUser = member ? member.user : await client.users.fetch(userId);
      await applicantUser.send({
        content: `Thank you for your interest in applying for the **Aozora** staff team. Unfortunately, your application has been **denied** at this time. You might not be eligible at the moment. We appreciate your time and effort.`
      });
    } catch (err) {
      actionDetails = "\n⚠️ Could not DM the user (their DMs might be closed).";
    }
  }

  // Update review embed in staff channel
  const oldEmbed = interaction.message.embeds[0];
  const durationText = appData.duration || "Unknown";

  const updatedEmbed = EmbedBuilder.from(oldEmbed)
    .setColor(isApprove ? '#2ecc71' : '#e74c3c')
    .setFields([]) // Clear existing fields to place them again (ensuring structure integrity)
    .addFields(oldEmbed.fields)
    .addFields({
      name: isApprove ? "✅ Application Approved" : "❌ Application Denied",
      value: `Processed by ${staffUser} (${staffUser.tag}) on <t:${Math.floor(Date.now() / 1000)}:f>\n**Time taken to apply:** ${durationText}${actionDetails}`,
      inline: false
    });

  // Update staff message: update embed and remove/disable buttons
  const disabledRow = new ActionRowBuilder().addComponents(
    new ButtonBuilder()
      .setCustomId('approved_placeholder')
      .setLabel(isApprove ? 'Approved' : 'Denied')
      .setStyle(isApprove ? ButtonStyle.Success : ButtonStyle.Danger)
      .setDisabled(true)
  );

  await interaction.message.edit({
    embeds: [updatedEmbed],
    components: [disabledRow]
  });

  // Clean up database cache for this processed application as requested
  database.deleteSubmittedApplication(messageId);

  await interaction.followUp({ content: `✅ Application successfully **${newStatus}**.`, ephemeral: true });
}

/**
 * Helper to format duration in milliseconds to a human-readable text block.
 */
function formatDuration(ms) {
  const totalSeconds = Math.floor(ms / 1000);
  const minutes = Math.floor(totalSeconds / 60);
  const seconds = totalSeconds % 60;
  
  if (minutes === 0) {
    return `${seconds} second${seconds !== 1 ? 's' : ''}`;
  }
  return `${minutes} minute${minutes !== 1 ? 's' : ''}, ${seconds} second${seconds !== 1 ? 's' : ''}`;
}

/**
 * Safely disables buttons on an interaction message.
 */
async function disableMessageButtons(message) {
  try {
    const disabledRows = message.components.map(row => {
      const newRow = ActionRowBuilder.from(row);
      newRow.components.forEach(comp => comp.setDisabled(true));
      return newRow;
    });
    await message.edit({ components: disabledRows });
  } catch (err) {
    console.error("Failed to disable buttons on message:", err);
  }
}

// Global unhandled exception catching to prevent the bot from crashing
process.on('unhandledRejection', (reason, promise) => {
  console.error('Unhandled Rejection at:', promise, 'reason:', reason);
});

process.on('uncaughtException', (err) => {
  console.error('Uncaught Exception thrown:', err);
});

// Bot login
if (process.env.DISCORD_TOKEN && process.env.DISCORD_TOKEN !== 'YOUR_DISCORD_BOT_TOKEN_HERE') {
  client.login(process.env.DISCORD_TOKEN).catch(err => {
    console.error("❌ Failed to log in to Discord. Check your DISCORD_TOKEN in the .env file.");
    console.error(err);
  });
} else {
  console.warn("⚠️ DISCORD_TOKEN not set in environment. Please edit the .env file and set your Discord bot token to run.");
}
