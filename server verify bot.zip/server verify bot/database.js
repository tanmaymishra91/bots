import sqlite3 from 'sqlite3';
import { dirname, join } from 'path';
import { fileURLToPath } from 'url';

const __dirname = dirname(fileURLToPath(import.meta.url));
const dbPath = join(__dirname, 'tokens.db');

const db = new sqlite3.Database(dbPath, (err) => {
  if (err) {
    console.error('Failed to open database:', err.message);
  } else {
    console.log('Connected to the SQLite database.');
  }
});

// Helper wrapper for db.run (for inserts/updates/deletes)
const run = (sql, params = []) => new Promise((resolve, reject) => {
  db.run(sql, params, function(err) {
    if (err) reject(err);
    else resolve(this);
  });
});

// Helper wrapper for db.get (for fetching a single row)
const get = (sql, params = []) => new Promise((resolve, reject) => {
  db.get(sql, params, (err, row) => {
    if (err) reject(err);
    else resolve(row);
  });
});

// Helper wrapper for db.all (for fetching multiple rows)
const all = (sql, params = []) => new Promise((resolve, reject) => {
  db.all(sql, params, (err, rows) => {
    if (err) reject(err);
    else resolve(rows);
  });
});

// Initialize database schema
export async function initDatabase() {
  await run(`
    CREATE TABLE IF NOT EXISTS user_tokens (
      user_id TEXT PRIMARY KEY,
      username TEXT,
      access_token TEXT,
      refresh_token TEXT,
      expires_at INTEGER
    )
  `);
  console.log('Database initialized successfully.');
}

// Save or update token
export async function saveToken(userId, username, accessToken, refreshToken, expiresIn) {
  // Calculate absolute expiration timestamp (current timestamp + seconds remaining * 1000)
  const expiresAt = Date.now() + (expiresIn * 1000);
  await run(
    `INSERT OR REPLACE INTO user_tokens (user_id, username, access_token, refresh_token, expires_at) 
     VALUES (?, ?, ?, ?, ?)`,
    [userId, username, accessToken, refreshToken, expiresAt]
  );
}

// Retrieve token
export async function getToken(userId) {
  return await get(`SELECT * FROM user_tokens WHERE user_id = ?`, [userId]);
}

// Get all stored tokens
export async function getAllTokens() {
  return await all(`SELECT * FROM user_tokens`);
}

// Delete user token
export async function deleteToken(userId) {
  await run(`DELETE FROM user_tokens WHERE user_id = ?`, [userId]);
}
