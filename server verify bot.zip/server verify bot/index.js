import { 
  Client, 
  GatewayIntentBits, 
  EmbedBuilder, 
  ActionRowBuilder, 
  ButtonBuilder, 
  ButtonStyle
} from 'discord.js';
import express from 'express';
import dotenv from 'dotenv';
import { 
  initDatabase, 
  saveToken, 
  getToken, 
  deleteToken 
} from './database.js';

dotenv.config();

const {
  DISCORD_TOKEN,
  CLIENT_ID,
  CLIENT_SECRET,
  REDIRECT_URI,
  PORT,
  GUILD_ID,
  VERIFICATION_CHANNEL_ID,
  VERIFIED_ROLE_ID,
  CONTROL_GUILD_ID,
  CONTROL_CHANNEL_ID
} = process.env;

// Validate Environment Variables
if (!DISCORD_TOKEN || DISCORD_TOKEN.includes('YOUR_BOT_TOKEN')) {
  console.error('Error: DISCORD_TOKEN is missing or not set in .env');
  process.exit(1);
}
if (!CLIENT_ID || CLIENT_ID.includes('YOUR_CLIENT_ID')) {
  console.error('Error: CLIENT_ID is missing or not set in .env');
  process.exit(1);
}
if (!CLIENT_SECRET || CLIENT_SECRET.includes('YOUR_CLIENT_SECRET')) {
  console.error('Error: CLIENT_SECRET is missing or not set in .env');
  process.exit(1);
}
if (!REDIRECT_URI) {
  console.error('Error: REDIRECT_URI is missing in .env');
  process.exit(1);
}
if (!GUILD_ID) {
  console.error('Error: GUILD_ID is missing in .env');
  process.exit(1);
}
if (!VERIFICATION_CHANNEL_ID) {
  console.error('Error: VERIFICATION_CHANNEL_ID is missing in .env');
  process.exit(1);
}
if (!VERIFIED_ROLE_ID) {
  console.error('Error: VERIFIED_ROLE_ID is missing in .env');
  process.exit(1);
}
if (!CONTROL_GUILD_ID) {
  console.error('Error: CONTROL_GUILD_ID is missing in .env');
  process.exit(1);
}
if (!CONTROL_CHANNEL_ID) {
  console.error('Error: CONTROL_CHANNEL_ID is missing in .env');
  process.exit(1);
}

const serverPort = PORT || 3000;

// Initialize SQLite Database
await initDatabase();

// Initialize Discord Client (No Slash Command intents needed)
const client = new Client({
  intents: [
    GatewayIntentBits.Guilds,
    GatewayIntentBits.GuildMembers,
    GatewayIntentBits.GuildMessages,
    GatewayIntentBits.MessageContent
  ]
});

// Bot Startup Check (Auto-detects and posts verification embed if missing)
client.once('ready', async () => {
  console.log(`Bot logged in as ${client.user.tag}!`);
  
  try {
    const channel = await client.channels.fetch(VERIFICATION_CHANNEL_ID).catch(() => null);
    if (!channel) {
      console.error(`Verification channel with ID ${VERIFICATION_CHANNEL_ID} not found or inaccessible by the bot.`);
      return;
    }

    // Fetch the last 50 messages in the channel to search for an existing panel
    const messages = await channel.messages.fetch({ limit: 50 });
    
    // Check if there is already a message sent by this bot containing the verification embed/button
    const botMessageExists = messages.some(msg => 
      msg.author.id === client.user.id && 
      msg.embeds.length > 0 && 
      msg.components.length > 0
    );

    if (!botMessageExists) {
      console.log('No verification panel detected. Sending new panel...');
      
      const verifyUrl = `https://discord.com/oauth2/authorize?client_id=${CLIENT_ID}&redirect_uri=${encodeURIComponent(REDIRECT_URI)}&response_type=code&scope=identify%20guilds.join`;

      const embed = new EmbedBuilder()
        .setTitle('🛡️ Server Verification')
        .setDescription(
          'Welcome to our server! To gain full access, you must verify your account.\n\n' +
          'Click the **Verify Me** button below. This will open a page asking you to authorize our bot to join servers on your behalf. ' +
          'Once authorized, you will automatically be granted the verified role and unlocked access.'
        )
        .setColor('#00ff88')
        .setTimestamp()
        .setFooter({ text: `${channel.guild.name} Verification` });

      const button = new ButtonBuilder()
        .setLabel('Verify Me')
        .setStyle(ButtonStyle.Link)
        .setURL(verifyUrl)
        .setEmoji('✅');

      const row = new ActionRowBuilder().addComponents(button);

      await channel.send({
        embeds: [embed],
        components: [row]
      });
      console.log('Verification panel sent successfully.');
    } else {
      console.log('Verification panel already exists in the channel. Skipping post to avoid duplicates.');
    }
  } catch (error) {
    console.error('Error during startup verification panel check:', error);
  }
});

// Auto-assign verified role when a user joins (in case they verified but left the guild)
client.on('guildMemberAdd', async (member) => {
  if (member.guild.id !== GUILD_ID) return;

  try {
    const tokenRecord = await getToken(member.id);
    if (tokenRecord) {
      console.log(`Auto-assigning role to joining verified member: ${member.user.tag}`);
      await member.roles.add(VERIFIED_ROLE_ID);
    }
  } catch (error) {
    console.error(`Error checking/assigning role on member join for ${member.id}:`, error);
  }
});

// Helper: Refresh Discord OAuth2 Token if expired/near expiry
async function getOrRefreshToken(userId) {
  const record = await getToken(userId);
  if (!record) return null;

  // If token is expired or expires in less than 5 minutes, refresh it
  if (record.expires_at - Date.now() < 300000) {
    console.log(`Refreshing access token for user ID: ${userId}`);
    try {
      const response = await fetch('https://discord.com/api/v10/oauth2/token', {
        method: 'POST',
        headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
        body: new URLSearchParams({
          client_id: CLIENT_ID,
          client_secret: CLIENT_SECRET,
          grant_type: 'refresh_token',
          refresh_token: record.refresh_token
        })
      });

      const data = await response.json();
      if (!response.ok) {
        throw new Error(data.error_description || data.error || 'Failed to refresh token');
      }

      await saveToken(userId, record.username, data.access_token, data.refresh_token, data.expires_in);
      console.log(`Token refreshed successfully for user ID: ${userId}`);
      return data.access_token;
    } catch (error) {
      console.error(`Failed to refresh token for user ${userId}:`, error.message);
      // If refresh token is invalid/revoked, delete the token record
      await deleteToken(userId);
      return null;
    }
  }

  return record.access_token;
}

// Helper: Add user to guild and assign verified role
async function addUserToGuild(userId, accessToken) {
  try {
    const response = await fetch(`https://discord.com/api/v10/guilds/${GUILD_ID}/members/${userId}`, {
      method: 'PUT',
      headers: {
        'Authorization': `Bot ${DISCORD_TOKEN}`,
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({
        access_token: accessToken,
        roles: [VERIFIED_ROLE_ID]
      })
    });

    if (response.status === 201) {
      console.log(`Successfully added user ID ${userId} to guild ${GUILD_ID} with verified role.`);
      return { success: true, action: 'joined' };
    } else if (response.status === 204) {
      console.log(`User ID ${userId} is already in guild ${GUILD_ID}. Assigning role manually.`);
      
      // If user is already in guild, manually assign the role.
      const guild = await client.guilds.fetch(GUILD_ID);
      const member = await guild.members.fetch(userId).catch(() => null);
      if (member) {
        await member.roles.add(VERIFIED_ROLE_ID);
        return { success: true, action: 'verified' };
      }
      return { success: false, error: 'User is in guild but bot cannot fetch member object.' };
    } else {
      const errorData = await response.json();
      console.error(`Guild join API error for user ${userId}:`, errorData);
      return { success: false, error: errorData.message || 'API error' };
    }
  } catch (error) {
    console.error(`Network or permission error adding user ${userId}:`, error);
    return { success: false, error: error.message };
  }
}

// Message Event Command listener (.reinvite <userId>) in the control server
client.on('messageCreate', async (message) => {
  if (message.author.bot) return;

  // Verify command is in control guild and control channel
  if (message.guildId === CONTROL_GUILD_ID && message.channelId === CONTROL_CHANNEL_ID) {
    if (message.content.startsWith('.reinvite')) {
      const args = message.content.split(/\s+/);
      const targetUserId = args[1];

      if (!targetUserId || !/^\d{17,20}$/.test(targetUserId)) {
        return message.reply('❌ **Invalid Command Usage.** Use: `.reinvite <User_ID>` (Example: `.reinvite 1029700789746278440`)');
      }

      const statusMsg = await message.reply(`⏳ Attempting to reinvite and verify user **${targetUserId}**...`);

      try {
        const accessToken = await getOrRefreshToken(targetUserId);
        if (!accessToken) {
          return statusMsg.edit(`❌ **Reinvite Failed.** No valid verification token was found for User ID \`${targetUserId}\`. They must verify through the bot link first.`);
        }

        const result = await addUserToGuild(targetUserId, accessToken);

        if (result.success) {
          if (result.action === 'joined') {
            await statusMsg.edit(`✅ **Success!** Reinvited user ID \`${targetUserId}\` back to the server and automatically assigned the verified role.`);
          } else {
            await statusMsg.edit(`✅ **Success!** User ID \`${targetUserId}\` is already in the server. They have been manually granted the verified role.`);
          }
        } else {
          await statusMsg.edit(`❌ **Failed to join/verify user:** ${result.error}`);
        }
      } catch (error) {
        console.error('Error in reinvite handler:', error);
        await statusMsg.edit(`❌ **An unexpected error occurred:** ${error.message}`);
      }
    }
  }
});

// Express Web Server
const app = express();

app.get('/callback', async (req, res) => {
  const { code } = req.query;

  if (!code) {
    return res.status(400).send('Bad Request: Missing authorization code.');
  }

  try {
    // 1. Exchange OAuth2 Code for Tokens
    const tokenResponse = await fetch('https://discord.com/api/v10/oauth2/token', {
      method: 'POST',
      headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
      body: new URLSearchParams({
        client_id: CLIENT_ID,
        client_secret: CLIENT_SECRET,
        grant_type: 'authorization_code',
        code: code,
        redirect_uri: REDIRECT_URI
      })
    });

    const tokenData = await tokenResponse.json();
    if (!tokenResponse.ok) {
      throw new Error(tokenData.error_description || tokenData.error || 'Failed to exchange code');
    }

    const { access_token, refresh_token, expires_in } = tokenData;

    // 2. Fetch User Details
    const userResponse = await fetch('https://discord.com/api/v10/users/@me', {
      method: 'GET',
      headers: { 'Authorization': `Bearer ${access_token}` }
    });

    const userData = await userResponse.json();
    if (!userResponse.ok) {
      throw new Error(userData.message || 'Failed to fetch user data');
    }

    const userId = userData.id;
    const username = `${userData.username}#${userData.discriminator}`;

    // NOTE: We keep the token in SQLite database to support the .reinvite command. 
    // If you ever want to delete it manually, you can clear tokens.db, but doing so will break the .reinvite command.
    // 3. Save tokens to DB
    await saveToken(userId, username, access_token, refresh_token, expires_in);

    // 4. Force Join Main Guild and assign Verified Role
    await addUserToGuild(userId, access_token);

    // 5. Send aesthetic confirmation page to user
    res.send(`
      <!DOCTYPE html>
      <html lang="en">
      <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Verification Successful</title>
        <style>
          body {
            background: radial-gradient(circle at center, #1b202e 0%, #0d0f14 100%);
            color: #ffffff;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            margin: 0;
            overflow: hidden;
          }
          .card {
            background: rgba(255, 255, 255, 0.03);
            backdrop-filter: blur(10px);
            border: 1px solid rgba(255, 255, 255, 0.05);
            padding: 40px;
            border-radius: 20px;
            text-align: center;
            box-shadow: 0 8px 32px 0 rgba(0, 0, 0, 0.3);
            max-width: 400px;
            animation: fadeIn 0.8s ease-out;
          }
          .checkmark-wrapper {
            width: 80px;
            height: 80px;
            background: rgba(0, 255, 136, 0.1);
            border-radius: 50%;
            display: flex;
            justify-content: center;
            align-items: center;
            margin: 0 auto 20px auto;
            border: 2px solid #00ff88;
            box-shadow: 0 0 20px rgba(0, 255, 136, 0.2);
          }
          .checkmark {
            font-size: 40px;
            color: #00ff88;
          }
          h1 {
            margin: 0 0 10px 0;
            font-size: 24px;
            font-weight: 600;
            letter-spacing: 0.5px;
          }
          p {
            color: #a0a5b5;
            font-size: 14px;
            line-height: 1.5;
            margin: 0 0 20px 0;
          }
          .footer-text {
            color: rgba(255, 255, 255, 0.2);
            font-size: 12px;
            margin-top: 10px;
          }
          @keyframes fadeIn {
            from { opacity: 0; transform: translateY(20px); }
            to { opacity: 1; transform: translateY(0); }
          }
        </style>
      </head>
      <body>
        <div class="card">
          <div class="checkmark-wrapper">
            <span class="checkmark">✓</span>
          </div>
          <h1>Verification Completed</h1>
          <p>Thank you for verifying, <strong>${userData.username}</strong>! You have been successfully verified and granted access to the server. You may now close this tab.</p>
          <div class="footer-text">Secure Verification System</div>
        </div>
      </body>
      </html>
    `);

  } catch (error) {
    console.error('OAuth2 Callback Error:', error);
    res.status(500).send(`
      <!DOCTYPE html>
      <html lang="en">
      <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Verification Failed</title>
        <style>
          body {
            background: #0d0f14;
            color: #ffffff;
            font-family: sans-serif;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            margin: 0;
          }
          .card {
            background: rgba(255, 0, 0, 0.05);
            border: 1px solid #ff4444;
            padding: 30px;
            border-radius: 10px;
            text-align: center;
            max-width: 400px;
          }
          h1 { color: #ff4444; }
        </style>
      </head>
      <body>
        <div class="card">
          <h1>Verification Failed</h1>
          <p>Something went wrong during verification: ${error.message}</p>
          <p>Please close this page and try clicking the verify button again.</p>
        </div>
      </body>
      </html>
    `);
  }
});

// Start Express Server
app.listen(serverPort, () => {
  console.log(`OAuth2 callback server listening on port ${serverPort}`);
});

// Start Discord Client
client.login(DISCORD_TOKEN).catch(error => {
  console.error('Failed to log in to Discord. Verify your DISCORD_TOKEN is correct.', error);
});
