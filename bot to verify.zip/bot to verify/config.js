require('dotenv').config();

module.exports = {
  // Bot secrets
  token: process.env.DISCORD_TOKEN,

  // Server configurations
  guilds: {
    main: '1231482071499800638',       // Main Server (Aozora)
    staff: '1287247262023548998'       // Staff Server
  },

  // Channel configurations
  channels: {
    apply: '1518548071703904376',      // Channel where the "Apply" message will be sent
    staffReview: '1518515506699829338' // Staff channel where applications are reviewed
  },

  // Role configurations
  roles: {
    verifiedSelfie: '1518546190138867812' // "Verified Selfie" role on the main server
  },

  // File configurations
  exampleImageName: 'example image.jpeg'
};
