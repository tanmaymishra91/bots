const fs = require('fs');
const path = require('path');

const DB_FILE = path.join(__dirname, 'database.json');

/**
 * Loads the current state of the database from the JSON file.
 * If the file doesn't exist, it creates a new empty one.
 */
function loadDB() {
  if (!fs.existsSync(DB_FILE)) {
    fs.writeFileSync(DB_FILE, JSON.stringify({ userStates: {} }, null, 2), 'utf8');
  }
  try {
    const data = fs.readFileSync(DB_FILE, 'utf8');
    return JSON.parse(data);
  } catch (err) {
    console.error('Error reading database file, returning empty structure:', err);
    return { userStates: {} };
  }
}

/**
 * Saves the database state back to the JSON file.
 */
function saveDB(db) {
  try {
    fs.writeFileSync(DB_FILE, JSON.stringify(db, null, 2), 'utf8');
  } catch (err) {
    console.error('Error writing database file:', err);
  }
}

module.exports = {
  /**
   * Retrieves the state of a user.
   * @param {string} userId
   * @returns {object|null}
   */
  getUserState(userId) {
    const db = loadDB();
    return db.userStates[userId] || null;
  },

  /**
   * Sets the state of a user.
   * @param {string} userId
   * @param {string} state
   * @param {string|null} pendingImageUrl
   */
  setUserState(userId, state, pendingImageUrl = null) {
    const db = loadDB();
    db.userStates[userId] = {
      state,
      pendingImageUrl,
      updatedAt: Date.now()
    };
    saveDB(db);
  },

  /**
   * Clears a user's state after completion or cancellation.
   * @param {string} userId
   */
  clearUserState(userId) {
    const db = loadDB();
    delete db.userStates[userId];
    saveDB(db);
  }
};
