# Aozora Selfie Verification Bot

A Node.js Discord bot designed using `discord.js` v14 to automate the selfie verification process for the **Aozora** server.

## Features
- **Auto-Setup Verification Message:** On startup, the bot checks the verification channel and automatically posts the instruction embed along with the example image and an "Apply" button if it is not already present.
- **Interactive DM Flow:** When a user clicks the Apply button, the bot guides them step-by-step through DMs, prompting them to send their selfie.
- **Double-Confirmation:** Users receive a visual preview of their uploaded selfie and must click "Confirm & Submit" before it is sent to staff.
- **Staff Control Panel:** Applications are sent to a designated staff channel with buttons to Approve or Deny.
- **Modal Input for Denial Reason:** Denying an application opens a modal prompt for staff to enter a reason, which is then direct messaged to the applicant automatically.
- **Auto-Cleanup Cache/Database:** To keep memory usage and disk storage footprint clean, all application states are instantly purged once a decision (Approve/Deny) is made.

---

## Prerequisites
- Node.js (v16.9.0 or higher is required for discord.js v14)
- NPM (Node Package Manager)
- A Discord Bot Token with the following **Privileged Gateway Intents** enabled in the [Discord Developer Portal](https://discord.com/developers/applications):
  - **Server Members Intent** (required to fetch server members and assign roles)
  - **Message Content Intent** (required to read verification images sent in DMs)

---

## Installation & Setup

1. **Clone/Copy Files:** Make sure the following files are in your project directory:
   - `index.js`
   - `config.js`
   - `database.js`
   - `package.json`
   - `.env`
   - `example image.jpeg`

2. **Configure Environment:** Open `.env` and paste your Discord bot token:
   ```env
   DISCORD_TOKEN=your_bot_token_here
   ```

3. **Install dependencies:**
   ```bash
   npm install
   ```

4. **Start the Bot:**
   ```bash
   npm start
   ```

---

## How Database & Cache Cleanup Works
To keep the bot lightweight and prevent memory leaks:
1. **Stateless Review Button Processing:** The buttons sent to the staff channel contain the applicant's user ID embedded inside their custom IDs (e.g. `staff_approve_3821034...`). This removes the need for keeping active application mappings in memory.
2. **Instant Purge:** Upon clicking **Approve** or submitting a reason for **Deny**, the bot calls `database.clearUserState(applicantId)` which deletes the user's data from memory and saves the cleaned state to `database.json`.
3. **No Local Media Storing:** Submitted selfie images are passed to Discord as attachments and re-uploaded directly. The bot does not write any image files to your local disk, preventing storage bloat.
