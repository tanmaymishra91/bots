const {
  Client,
  GatewayIntentBits,
  Partials,
  EmbedBuilder,
  ButtonBuilder,
  ButtonStyle,
  ActionRowBuilder,
  ModalBuilder,
  TextInputBuilder,
  TextInputStyle,
  AttachmentBuilder,
  ChannelType
} = require('discord.js');
const fs = require('fs');
const path = require('path');
const config = require('./config');
const database = require('./database');

// Create Client with required Intents and Partials (crucial for DM support in v14)
const client = new Client({
  intents: [
    GatewayIntentBits.Guilds,
    GatewayIntentBits.GuildMembers,
    GatewayIntentBits.GuildMessages,
    GatewayIntentBits.DirectMessages,
    GatewayIntentBits.MessageContent
  ],
  partials: [
    Partials.Channel,
    Partials.Message,
    Partials.User
  ]
});

client.once('ready', async () => {
  console.log(`Bot logged in successfully as ${client.user.tag}`);
  await setupApplyMessage();
});

/**
 * Searches the application channel for an existing bot message containing the Apply button.
 * If not found, posts the verification rules and button along with the example image.
 */
async function setupApplyMessage() {
  try {
    const mainGuild = await client.guilds.fetch(config.guilds.main).catch(() => null);
    if (!mainGuild) {
      console.error(`Error: Could not fetch main guild ${config.guilds.main}`);
      return;
    }

    const applyChannel = await mainGuild.channels.fetch(config.channels.apply).catch(() => null);
    if (!applyChannel) {
      console.error(`Error: Could not fetch apply channel ${config.channels.apply}`);
      return;
    }

    // Fetch the last 50 messages to check if the apply button message is already posted
    const messages = await applyChannel.messages.fetch({ limit: 50 });
    const existingMessage = messages.find(
      m => m.author.id === client.user.id && 
           m.components.some(row => row.components.some(c => c.customId === 'apply_verification'))
    );

    if (existingMessage) {
      console.log('Verification apply message already exists in the channel. Skipping creation.');
      return;
    }

    console.log('Verification apply message not found. Posting new one...');
    const imagePath = path.join(__dirname, config.exampleImageName);
    const files = [];
    let embedImageUrl = null;

    if (fs.existsSync(imagePath)) {
      const attachment = new AttachmentBuilder(imagePath, { name: 'example_image.jpeg' });
      files.push(attachment);
      embedImageUrl = 'attachment://example_image.jpeg';
      console.log(`Example image loaded: ${imagePath}`);
    } else {
      console.warn(`Warning: Example image not found at path: ${imagePath}`);
    }

    const embed = new EmbedBuilder()
      .setTitle('📷 Selfie Verification')
      .setDescription(
        "u gotta send an image of urself with a peace of paper with your clear face, it must written ur username of discord and our server name Aozora and todays current date when u apply.\n\n" +
        "### 🛑 Strict Rules (Read Carefully)\n" +
        "* **Must be readable:** The text on the paper must be clear, legible, and easy to read.\n" +
        "* **No filters allowed:** Do not use beauty filters, face-altering apps, or digital text overlays.\n" +
        "* **Do not cover your face:** Your full face must be clearly visible alongside the paper."
      )
      .setColor('#5865F2');

    if (embedImageUrl) {
      embed.setImage(embedImageUrl);
    }

    const button = new ButtonBuilder()
      .setCustomId('apply_verification')
      .setLabel('Apply')
      .setStyle(ButtonStyle.Primary)
      .setEmoji('📝');

    const row = new ActionRowBuilder().addComponents(button);

    await applyChannel.send({
      embeds: [embed],
      components: [row],
      files: files
    });

    console.log('Verification apply message posted successfully.');
  } catch (error) {
    console.error('Error setting up the apply message:', error);
  }
}

client.on('interactionCreate', async (interaction) => {
  try {
    if (interaction.isButton()) {
      await handleButtonInteraction(interaction);
    } else if (interaction.isModalSubmit()) {
      await handleModalSubmit(interaction);
    }
  } catch (error) {
    console.error('Error handling interaction:', error);
    // Attempt to reply to interaction if not acknowledged
    if (interaction.isRepliable() && !interaction.replied && !interaction.deferred) {
      await interaction.reply({ content: '❌ There was an error processing this request.', ephemeral: true }).catch(() => {});
    }
  }
});

async function handleButtonInteraction(interaction) {
  const { customId, user } = interaction;

  // ----------------------------------------------------
  // BUTTON: Apply (clicked in server channel)
  // ----------------------------------------------------
  if (customId === 'apply_verification') {
    const member = await interaction.guild.members.fetch(user.id).catch(() => null);
    
    // Check if the user is already verified
    if (member && member.roles.cache.has(config.roles.verifiedSelfie)) {
      return interaction.reply({
        content: '✨ You are already verified in the server!',
        ephemeral: true
      });
    }

    // Check if there's already a pending submission being reviewed
    const currentState = database.getUserState(user.id);
    if (currentState && currentState.state === 'SUBMITTED') {
      return interaction.reply({
        content: '⏳ You already have a pending verification request. Staff will review it as soon as possible!',
        ephemeral: true
      });
    }

    try {
      // Try sending a DM to prompt application
      await user.send(
        `👋 Hello! You've started the verification process for **Aozora**.\n\n` +
        `Please send your verification selfie directly in this DM. Make sure it contains:\n` +
        `1. Your clear face.\n` +
        `2. A piece of paper with your Discord username (\`${user.username}\`), the server name (**Aozora**), and today's date.\n\n` +
        `Please reply to this DM by uploading your image.`
      );

      // Save user state
      database.setUserState(user.id, 'WAITING_FOR_IMAGE');
      
      await interaction.reply({
        content: '📩 I\'ve sent you a DM with instructions. Please check your DMs!',
        ephemeral: true
      });
    } catch (dmError) {
      console.warn(`Failed to send DM to ${user.tag}:`, dmError);
      await interaction.reply({
        content: '❌ I couldn\'t send you a DM. Please enable DMs from server members in your privacy settings and try again!',
        ephemeral: true
      });
    }
    return;
  }

  // ----------------------------------------------------
  // BUTTON: Confirm & Submit (clicked in DMs)
  // ----------------------------------------------------
  if (customId === 'confirm_submit') {
    const state = database.getUserState(user.id);
    if (!state || state.state !== 'CONFIRM_PENDING' || !state.pendingImageUrl) {
      return interaction.reply({
        content: '❌ No pending application was found or it has expired. Please click Apply again on the server.',
        ephemeral: true
      });
    }

    await interaction.reply({
      content: '⌛ Sending application to staff...',
      ephemeral: true
    });

    try {
      const staffGuild = await client.guilds.fetch(config.guilds.staff).catch(() => null);
      if (!staffGuild) throw new Error('Staff guild could not be fetched.');

      const staffChannel = await staffGuild.channels.fetch(config.channels.staffReview).catch(() => null);
      if (!staffChannel) throw new Error('Staff review channel could not be fetched.');

      // Re-upload the attachment so it doesn't break if the DM message is deleted/expires
      const attachment = new AttachmentBuilder(state.pendingImageUrl, { name: 'selfie_verification.png' });

      const reviewEmbed = new EmbedBuilder()
        .setTitle('🆕 New Selfie Verification Request')
        .setColor('#F1C40F') // Pending Yellow
        .addFields([
          { name: 'User', value: `<@${user.id}>`, inline: true },
          { name: 'Username', value: user.username, inline: true },
          { name: 'User ID', value: user.id, inline: true }
        ])
        .setImage('attachment://selfie_verification.png')
        .setTimestamp();

      const approveBtn = new ButtonBuilder()
        .setCustomId(`staff_approve_${user.id}`)
        .setLabel('Approve')
        .setStyle(ButtonStyle.Success);

      const denyBtn = new ButtonBuilder()
        .setCustomId(`staff_deny_${user.id}`)
        .setLabel('Deny')
        .setStyle(ButtonStyle.Danger);

      const row = new ActionRowBuilder().addComponents(approveBtn, denyBtn);

      await staffChannel.send({
        embeds: [reviewEmbed],
        files: [attachment],
        components: [row]
      });

      // Update state to submitted
      database.setUserState(user.id, 'SUBMITTED', state.pendingImageUrl);

      // Thank the user in DMs
      await user.send('✨ Thank you! Your verification request has been sent to staff for review. You will be notified here once a decision has been made.');
      await interaction.editReply({ content: '✅ Submitted successfully! You can close this message.' });

    } catch (err) {
      console.error('Error submitting application:', err);
      await interaction.editReply({ content: '❌ There was an error sending your application to staff. Please contact server administration.' });
    }
    return;
  }

  // ----------------------------------------------------
  // BUTTON: Cancel (clicked in DMs)
  // ----------------------------------------------------
  if (customId === 'cancel_submit') {
    database.clearUserState(user.id);
    return interaction.reply({
      content: '❌ Application cancelled. You can click Apply again in the server whenever you are ready.',
      ephemeral: true
    });
  }

  // ----------------------------------------------------
  // BUTTON: Staff Approve (clicked in Staff Channel)
  // ----------------------------------------------------
  if (customId.startsWith('staff_approve_')) {
    const applicantId = customId.split('_')[2];
    await interaction.deferReply({ ephemeral: true });

    try {
      const mainGuild = await client.guilds.fetch(config.guilds.main);
      const member = await mainGuild.members.fetch(applicantId).catch(() => null);

      if (!member) {
        await interaction.editReply({ content: '❌ Applicant is no longer in the main server.' });
        await disableButtons(interaction.message, 'Applicant not in server');
        database.clearUserState(applicantId);
        return;
      }

      const role = mainGuild.roles.cache.get(config.roles.verifiedSelfie);
      if (!role) {
        return interaction.editReply({ content: '❌ Verified Selfie role not found in the main server configuration.' });
      }

      // Add verified role to user
      await member.roles.add(role);

      // Send approval DM to applicant
      const applicantUser = await client.users.fetch(applicantId).catch(() => null);
      if (applicantUser) {
        await applicantUser.send(`🎉 **Congratulations!** Your selfie verification request in **Aozora** has been approved! You have been granted the **Verified Selfie** role.`).catch(() => {
          console.warn(`Could not send approval DM to ${applicantUser.tag}`);
        });
      }

      // Edit staff message to show approval
      const originalEmbed = EmbedBuilder.from(interaction.message.embeds[0])
        .setTitle('✅ Selfie Verification Approved')
        .setColor('#2ECC71') // Approved Green
        .addFields({ name: 'Approved By', value: `<@${user.id}> (${user.username})`, inline: false })
        .setTimestamp();

      await interaction.message.edit({
        embeds: [originalEmbed],
        components: [] // Remove buttons
      });

      // Clear DB state for this user
      database.clearUserState(applicantId);

      await interaction.editReply({ content: '✅ Verification approved successfully!' });
    } catch (err) {
      console.error('Error approving verification:', err);
      await interaction.editReply({ content: `❌ Error processing approval: ${err.message}` });
    }
    return;
  }

  // ----------------------------------------------------
  // BUTTON: Staff Deny (clicked in Staff Channel)
  // ----------------------------------------------------
  if (customId.startsWith('staff_deny_')) {
    const applicantId = customId.split('_')[2];

    const modal = new ModalBuilder()
      .setCustomId(`deny_modal_${applicantId}`)
      .setTitle('Deny Verification');

    const reasonInput = new TextInputBuilder()
      .setCustomId('deny_reason')
      .setLabel('Reason for denial')
      .setStyle(TextInputStyle.Paragraph)
      .setRequired(true)
      .setPlaceholder("e.g., Text on paper is unreadable, beauty filter detected, or face is covered.")
      .setMaxLength(500);

    const row = new ActionRowBuilder().addComponents(reasonInput);
    modal.addComponents(row);

    await interaction.showModal(modal);
    return;
  }
}

/**
 * Handles Modal Submissions (Reason for denial)
 */
async function handleModalSubmit(interaction) {
  const { customId, user } = interaction;

  if (customId.startsWith('deny_modal_')) {
    const applicantId = customId.split('_')[2];
    const reason = interaction.fields.getTextInputValue('deny_reason');

    await interaction.deferReply({ ephemeral: true });

    try {
      // Send DM notifying denial with reason
      const applicantUser = await client.users.fetch(applicantId).catch(() => null);
      if (applicantUser) {
        await applicantUser.send(
          `✉️ We regret to inform you that your selfie verification request in **Aozora** has been denied.\n\n` +
          `**Reason for denial:** ${reason}\n\n` +
          `If you believe this is a mistake or would like to try again, please ensure you satisfy all requirements (readable text, no filters, clear face) and click Apply again in the server. u might be not elagable and etc.`
        ).catch(() => {
          console.warn(`Could not send denial DM to ${applicantUser.tag}`);
        });
      }

      // Update staff review message
      const originalEmbed = EmbedBuilder.from(interaction.message.embeds[0])
        .setTitle('❌ Selfie Verification Denied')
        .setColor('#E74C3C') // Denied Red
        .addFields([
          { name: 'Denied By', value: `<@${user.id}> (${user.username})`, inline: true },
          { name: 'Reason', value: reason, inline: false }
        ])
        .setTimestamp();

      await interaction.message.edit({
        embeds: [originalEmbed],
        components: [] // Remove buttons
      });

      // Clear state so user can apply again
      database.clearUserState(applicantId);

      await interaction.editReply({ content: '❌ Verification denied, applicant has been notified.' });
    } catch (err) {
      console.error('Error denying verification:', err);
      await interaction.editReply({ content: `❌ Error processing denial: ${err.message}` });
    }
  }
}

/**
 * Disables buttons on a staff review message if an issue occurs (e.g., member leaves server)
 */
async function disableButtons(message, reasonText) {
  try {
    const originalEmbed = EmbedBuilder.from(message.embeds[0])
      .setTitle(`⚠️ Application Closed (${reasonText})`)
      .setColor('#7F8C8D') // Grey
      .setTimestamp();

    await message.edit({
      embeds: [originalEmbed],
      components: []
    });
  } catch (err) {
    console.error('Failed to disable message buttons:', err);
  }
}

// ----------------------------------------------------
// EVENT: Message Create (Handles DMs from users)
// ----------------------------------------------------
client.on('messageCreate', async (message) => {
  // Ignore bots and message from guild channels
  if (message.author.bot) return;
  if (message.guild) return; // Simple and 100% reliable DM check

  const state = database.getUserState(message.author.id);

  // If user is not currently in a verification workflow
  if (!state || (state.state !== 'WAITING_FOR_IMAGE' && state.state !== 'CONFIRM_PENDING')) {
    await message.reply('👋 Hi! If you want to apply for selfie verification, please click the **Apply** button in the verification channel on the server.');
    return;
  }

  // Check for image attachments
  const attachment = message.attachments.first();
  const isImage = attachment && attachment.contentType && attachment.contentType.startsWith('image/');

  if (!isImage) {
    await message.reply('❌ Please upload an image attachment (e.g., JPEG, PNG) to apply.');
    return;
  }

  // Update user state to confirm pending with image URL
  database.setUserState(message.author.id, 'CONFIRM_PENDING', attachment.url);

  // Send confirmation embed
  const confirmEmbed = new EmbedBuilder()
    .setTitle('Review Your Application Image')
    .setDescription(
      'Is this the image you want to submit for verification? Please make sure it meets all the rules:\n\n' +
      '• Clear face visible\n' +
      '• Discord username, **Aozora**, and today\'s date written on paper\n' +
      '• No filters used\n\n' +
      'Click **Confirm & Submit** to send it to staff, or upload a different image to replace it.'
    )
    .setImage(attachment.url)
    .setColor('#3498DB');

  const confirmBtn = new ButtonBuilder()
    .setCustomId('confirm_submit')
    .setLabel('Confirm & Submit')
    .setStyle(ButtonStyle.Success);

  const cancelBtn = new ButtonBuilder()
    .setCustomId('cancel_submit')
    .setLabel('Cancel')
    .setStyle(ButtonStyle.Danger);

  const row = new ActionRowBuilder().addComponents(confirmBtn, cancelBtn);

  await message.reply({
    embeds: [confirmEmbed],
    components: [row]
  });
});

client.login(config.token);
